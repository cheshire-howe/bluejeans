<?php
require_once('../../config.php');

admin_externalpage_setup(get_string('useridsetup', 'block_bjn'));

echo $OUTPUT->header();

echo $OUTPUT->footer();