define(['jquery'], function($) {
    var success = {};

    success.init = function(success) {
        if (success) {
            $('#bjnmessage').text('Success').show();
            setTimeout(function() {
                $('#bjnmessage').slideUp('slow');
            }, 2000);
        }
    };

    return success;
})