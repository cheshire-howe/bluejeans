<?php
print(json_encode('{}'));
