<?php
$plugin->version = 2011062806;
$plugin->requires = 2010112400;
$plugin->cron = 300;